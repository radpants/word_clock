Word Clock - Screensaver

Installation:

-Double click on WordClock.saver, and select it in the preference pane (if necessary)

Report bugs to @radpants on twitter
http://twitter.com/radpants

Version 0.1
--------------------------	
Known Issues:
	-Has some weirdness when combined with the Fliqo screensaver in the system preferences window... it all works, it just doesn't preview the right screesaver.
	-The gnomes that write out the time are confused and thing that evening starts after noon... they are sleepy okay!
	-I made this late one night and it's bound to have typo's. Please let me know about them @radpants on twitter.